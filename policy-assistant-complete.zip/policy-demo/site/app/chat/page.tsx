import Demo from '../demo';
import knowledge from '@/lib/knowledge.json';
export default function Chat(){return <Demo catalog={{products:knowledge.products,documents:knowledge.documents,issues:knowledge.issues,stats:knowledge.stats}}/>;}
