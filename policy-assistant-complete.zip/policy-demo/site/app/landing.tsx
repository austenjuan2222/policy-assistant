'use client';
// Landing page in the Lumora layout (loader → hero with liquid reveal → about → band → products → features → stats → footer).
// Visual layer only: every number and product line comes from lib/knowledge.json; the Q&A workspace lives at /chat.
import {useEffect,useRef,useState} from 'react';
import type {CSSProperties,ElementType,HTMLAttributes,ReactNode} from 'react';
import {ShieldCheck,ArrowRight,ArrowUpRight,BookOpen,MessageSquare,Files,Calculator,X,Menu,CircleDot} from 'lucide-react';
import './landing.css';

type Product={id:string;name:string;short:string;category:string;description:string;version:string};
type Doc={product:string;kind:string};
type Props={products:Product[];documents:Doc[];stats:{documents:number;pdfPages:number;rates:number}};

const kindName:Record<string,string>={terms:'正式條款',dm:'商品 DM',rates:'費率表'};
const samples=[
 {caption:'保障查詢',title:'安新 100 意外住院如何給付？',p:'RAC'},
 {caption:'保費豁免',title:'享安心什麼情況可以豁免保費？',p:'RAE2'},
 {caption:'等待期間',title:'安心加倍防癌的等待期間多久？',p:'SCB'},
];
const features=[
 {n:'01',t:'客服問答',d:'白話提問，回答附上條款頁碼。',href:'/chat'},
 {n:'02',t:'文件資料庫',d:'條款、DM 與費率，保留版本可核對。',href:'/chat?tab=library'},
 {n:'03',t:'費率試算',d:'直接查表計算，數字對應原始儲存格。',href:'/chat?tab=rates'},
 {n:'04',t:'來源核對',d:'點選引用，即可開啟原始 PDF 頁面。',href:'/chat'},
];
// the 問 → 查證 → 安心 band: three steps that each open the matching tool, then a dark call to action
const bandSteps=[
 {n:'01',t:'問',d:'用白話輸入問題',href:'/chat',c:'light'},
 {n:'02',t:'查證',d:'點頁碼看條款原文',href:'/chat?tab=library',c:'accent'},
 {n:'03',t:'安心',d:'試算保費，核對儲存格',href:'/chat?tab=rates',c:'soft'},
 {n:'',t:'開始提問',d:'',href:'/chat',c:'dark'},
];
const navItems:[string,string][]=[['首頁','#home'],['商品','#products'],['功能','#features'],['關於','#about'],['文件資料庫','/chat?tab=library'],['開始提問','/chat']];
const heroWords=['等待期間','保費豁免','意外住院','給付條件','正式條款','費率表','失能給付','癌症保障','滿期給付','條款備查','特定癌症','手術給付','第 2 頁','商品 DM'];

/* ---------- small helpers ---------- */
const reducedMotion=()=>typeof window!=='undefined'&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
function useInView<T extends HTMLElement>(enabled=true){
 const ref=useRef<T>(null);const [inView,setIn]=useState(false);
 useEffect(()=>{const el=ref.current;if(!el||!enabled||inView)return;const io=new IntersectionObserver(([e])=>{if(e.isIntersecting){setIn(true);io.disconnect();}},{threshold:.15,rootMargin:'0px 0px -5% 0px'});io.observe(el);return()=>io.disconnect();},[enabled,inView]);
 return [ref,inView] as const;
}
function Reveal({as:Tag='div',className='',delay=0,from,gate,children,...rest}:{as?:ElementType;className?:string;delay?:number;from?:string;gate?:boolean;children?:ReactNode}&HTMLAttributes<HTMLElement>){
 const [ref,seen]=useInView<HTMLElement>(gate===undefined);
 const on=gate===undefined?seen:gate;
 return <Tag ref={ref} className={`lm-rv ${on?'in':''} ${className}`} style={{'--d':delay+'ms',...(from?{'--from':from}:{})} as CSSProperties} {...rest}>{children}</Tag>;
}
function Lines({as:Tag='h2',lines,className='',delay=0,stagger=0,gate}:{as?:ElementType;lines:string[];className?:string;delay?:number;stagger?:number;gate?:boolean}){
 const [ref,seen]=useInView<HTMLElement>(gate===undefined);
 const on=gate===undefined?seen:gate;
 return <Tag ref={ref} className={`lm-lines ${on?'in':''} ${className}`} aria-label={lines.join('')}>{lines.map((l,i)=><span key={i} className="lm-ln" aria-hidden="true"><span style={{'--d':delay+i*stagger+'ms'} as CSSProperties}>{l}</span></span>)}</Tag>;
}
function Chars({text,muted,className=''}:{text:string;muted:string;className?:string}){
 const [ref,seen]=useInView<HTMLHeadingElement>();
 let i=0;const split=(s:string)=>Array.from(s).map(c=><span key={i} className="lm-ch" style={{'--d':(i++)*14+'ms'} as CSSProperties}>{c}</span>);
 return <h2 ref={ref} className={`lm-chars ${seen?'in':''} ${className}`} aria-label={text+muted}><span aria-hidden="true">{split(text)}<span className="lm-muted">{split(muted)}</span></span></h2>;
}
function Pill({href,variant,arrow,children,onClick}:{href?:string;variant:'dark'|'light'|'outlined';arrow?:'right'|'up-right';children:ReactNode;onClick?:()=>void}){
 const inner=<span className="lm-pill-in">{children}{arrow&&<span className="lm-pill-badge">{arrow==='right'?<ArrowRight className="r"/>:<ArrowUpRight className="ur"/>}</span>}</span>;
 const cls=`lm-pill ${variant} ${arrow?'arrow':''}`;
 return href?<a className={cls} href={href} onClick={onClick}>{inner}</a>:<button type="button" className={cls} onClick={onClick}>{inner}</button>;
}
function formatClock(d:Date){const h=d.getHours();return {time:`${h<12?'上午':'下午'} ${h%12||12}:${String(d.getMinutes()).padStart(2,'0')}`,date:`${d.getFullYear()} 年 ${d.getMonth()+1} 月 ${d.getDate()} 日`};}

/* ---------- liquid reveal: brush paints the orange "highlighted clauses" layer over the grey one ---------- */
function drawPage(ctx:CanvasRenderingContext2D,w:number,h:number,accent:boolean){
 const g=ctx.createLinearGradient(0,0,0,h);
 if(accent){g.addColorStop(0,'#cf8047');g.addColorStop(1,'#97501f');}else{g.addColorStop(0,'#ecebe9');g.addColorStop(1,'#c9c9c9');}
 ctx.fillStyle=g;ctx.fillRect(0,0,w,h);
 // a quiet grid of policy terms; the brush reveals the same grid in orange, like a highlighter passing over a clause
 const size=Math.max(18,Math.round(w/34));
 ctx.font=`500 ${size}px Onest, "Noto Sans TC", sans-serif`;ctx.textBaseline='middle';
 ctx.fillStyle=accent?'rgba(255,255,255,.95)':'rgba(17,17,17,.06)';
 const rowH=size*2.4;let k=0;
 for(let r=0,y=rowH*.5;y<h+rowH;r++,y+=rowH){let x=-(r%4)*size*1.6;while(x<w){const word=heroWords[k++%heroWords.length];ctx.fillText(word,x,y);x+=ctx.measureText(word).width+size*2;}}
}
function LiquidReveal(){
 const wrap=useRef<HTMLDivElement>(null),base=useRef<HTMLCanvasElement>(null),top=useRef<HTMLCanvasElement>(null);
 useEffect(()=>{
  const el=wrap.current!,baseC=base.current!,canvas=top.current!;
  const bctx=baseC.getContext('2d')!,ctx=canvas.getContext('2d')!;
  const cover=document.createElement('canvas'),cctx=cover.getContext('2d')!;
  const brush=document.createElement('canvas'),brctx=brush.getContext('2d')!;
  const mask=document.createElement('canvas'),mctx=mask.getContext('2d')!;
  // phones: smaller brush and capped resolution so each stamp stays cheap and the trail keeps up with the finger
  const touch=window.matchMedia('(pointer: coarse)').matches;
  const brushRadius=touch?105:143,decay=0.016,fadeFrames=120,dpr=Math.min(window.devicePixelRatio||1,touch?1.5:2);
  // the highlighter only moves when the visitor moves the pointer, so it stays on even with reduced motion
  // (Windows laptops often have animation effects off, which used to disable it); only the automatic demo stroke respects it
  const autoDemo=!reducedMotion();
  let radius=brushRadius*dpr,diam=Math.ceil(radius*2),points:{x:number;y:number}[]=[],last:{x:number;y:number}|null=null,idle=fadeFrames+1,running=false,raf=0,W=0;
  function measure(){
   const r=el.getBoundingClientRect(),nextW=Math.max(1,Math.round(r.width*dpr)),H=Math.max(1,Math.round(r.height*dpr));
   if(nextW===W&&H===canvas.height)return; // ignore no-op resizes so the trail is not wiped mid-gesture
   W=nextW;
   for(const c of [baseC,canvas,cover]){c.width=W;c.height=H;}
   drawPage(bctx,W,H,false);drawPage(cctx,W,H,true);
   radius=brushRadius*dpr;diam=Math.ceil(radius*2);brush.width=brush.height=mask.width=mask.height=diam;
   // soft round mask is built once per size instead of once per stamp
   const c=diam/2,g=mctx.createRadialGradient(c,c,0,c,c,c);
   g.addColorStop(0,'rgba(255,255,255,1)');g.addColorStop(.55,'rgba(255,255,255,.82)');g.addColorStop(1,'rgba(255,255,255,0)');
   mctx.fillStyle=g;mctx.fillRect(0,0,diam,diam);
  }
  function stamp(x:number,y:number){
   const c=diam/2;brctx.globalCompositeOperation='copy';brctx.drawImage(mask,0,0);
   brctx.globalCompositeOperation='source-in';
   brctx.drawImage(cover,x-c,y-c,diam,diam,0,0,diam,diam);
   ctx.globalCompositeOperation='source-over';ctx.drawImage(brush,x-c,y-c);
  }
  function tick(){
   const drawing=points.length>0;
   if(drawing)idle=0;else{idle++;if(idle>fadeFrames){running=false;return;}}
   const fade=drawing?decay:Math.min(decay+idle*.004,.5);
   ctx.globalCompositeOperation='destination-out';ctx.fillStyle=`rgba(0,0,0,${fade})`;ctx.fillRect(0,0,canvas.width,canvas.height);
   if(drawing){points.forEach(p=>stamp(p.x,p.y));points=[];}
   if(idle===fadeFrames)ctx.clearRect(0,0,canvas.width,canvas.height);
   raf=requestAnimationFrame(tick);
  }
  function paint(clientX:number,clientY:number){
   const r=canvas.getBoundingClientRect(),x=(clientX-r.left)*dpr,y=(clientY-r.top)*dpr;
   if(x<-radius||y<-radius||x>canvas.width+radius||y>canvas.height+radius){last=null;return;}
   if(last){const dx=x-last.x,dy=y-last.y,dist=Math.hypot(dx,dy),step=Math.max(radius*(touch?.45:.3),1),n=Math.min(Math.ceil(dist/step),touch?24:60);for(let i=1;i<=n;i++)points.push({x:last.x+dx*i/n,y:last.y+dy*i/n});}else points.push({x,y});
   last={x,y};if(!running){running=true;raf=requestAnimationFrame(tick);}
  }
  // mouse/pen: pointermove. Touch: touch events, because pointermove stops (pointercancel) as soon as the page starts scrolling
  const onPointer=(e:PointerEvent)=>{if(e.pointerType!=='touch')paint(e.clientX,e.clientY);};
  const onTouchStart=(e:TouchEvent)=>{last=null;const t=e.touches[0];if(t)paint(t.clientX,t.clientY);};
  const onTouchMove=(e:TouchEvent)=>{const t=e.touches[0];if(t)paint(t.clientX,t.clientY);};
  const onTouchEnd=()=>{last=null;};
  const ro=new ResizeObserver(measure);ro.observe(el);measure();
  document.fonts?.ready.then(()=>{W=0;measure();});
  let demo=0,demoRaf=0;
  {
   window.addEventListener('pointermove',onPointer,{passive:true});
   window.addEventListener('touchstart',onTouchStart,{passive:true});
   window.addEventListener('touchmove',onTouchMove,{passive:true});
   window.addEventListener('touchend',onTouchEnd,{passive:true});
   // on phones there is no hover to discover the effect, so draw one short stroke after the intro
   if(touch&&autoDemo)demo=window.setTimeout(()=>{const r=el.getBoundingClientRect(),t0=performance.now();last=null;
    const step=(now:number)=>{const t=Math.min((now-t0)/900,1);paint(r.left+r.width*(.15+.7*t),r.top+r.height*(.22+.1*Math.sin(t*Math.PI*2)));if(t<1)demoRaf=requestAnimationFrame(step);else last=null;};
    demoRaf=requestAnimationFrame(step);},3400);
  }
  return()=>{ro.disconnect();window.removeEventListener('pointermove',onPointer);window.removeEventListener('touchstart',onTouchStart);window.removeEventListener('touchmove',onTouchMove);window.removeEventListener('touchend',onTouchEnd);clearTimeout(demo);cancelAnimationFrame(demoRaf);cancelAnimationFrame(raf);};
 },[]);
 return <div className="lm-lq" ref={wrap} aria-hidden="true"><canvas ref={base}/><canvas ref={top} className="lm-lq-top"/></div>;
}

/* ---------- page ---------- */
export default function Landing({products,documents,stats}:Props){
 const [ready,setReady]=useState(false),[progress,setProgress]=useState(0),[leaving,setLeaving]=useState(false),[showLoader,setShowLoader]=useState(true);
 const [clock,setClock]=useState({time:'上午 9:41',date:'2026 年 10 月 18 日'});
 const [menu,setMenu]=useState(false),[menuMounted,setMenuMounted]=useState(false);
 const [slide,setSlide]=useState(0),[prevSlide,setPrevSlide]=useState<number|null>(null),[dir,setDir]=useState(1);
 const statsRef=useRef<HTMLUListElement>(null);
 const statItems=[{v:products.length,s:'',l:'個商品'},{v:stats.documents,s:'',l:'份來源文件'},{v:stats.pdfPages,s:'',l:'頁可追溯 PDF'},{v:stats.rates,s:'',l:'筆費率資料'}];
 const [counts,setCounts]=useState(statItems.map(()=>0));
 const target=useRef(0),current=useRef(0),smoothing=useRef(false);

 // rem-based adaptive grid (same breakpoints and scale-up formula as Lumora), only while this page is mounted
 useEffect(()=>{
  const html=document.documentElement;
  function apply(){const w=window.innerWidth;let size:number;
   if(w>1920){size=16-(16*(((1920-w)/1920)*100*.6666))/100;}else if(w>1440)size=w*.00833333;else if(w>1024)size=w*.0111111;else if(w>640)size=w*.015625;else size=w*.0444444;
   html.style.fontSize=size+'px';}
  apply();window.addEventListener('resize',apply);
  return()=>{window.removeEventListener('resize',apply);html.style.removeProperty('font-size');};
 },[]);

 // loader: 000 → 100 over 2000ms (easeInOutCubic), holds briefly at 100, then slides up. Plays on every visit:
 // the server always renders it, so skipping it client-side only produced a dark flash.
 // With reduced motion the count still runs; the global reduced-motion CSS makes the exit instant.
 useEffect(()=>{
  document.documentElement.style.overflow='hidden';
  const t0=performance.now(),ease=(t:number)=>t<.5?4*t*t*t:1-Math.pow(-2*t+2,3)/2;let raf=0,timer=0,hold=0;
  const finish=()=>{setShowLoader(false);setReady(true);document.documentElement.style.removeProperty('overflow');};
  const tick=(now:number)=>{const t=Math.min((now-t0)/2000,1);setProgress(Math.round(ease(t)*100));
   if(t<1)raf=requestAnimationFrame(tick);
   else hold=window.setTimeout(()=>{setLeaving(true);timer=window.setTimeout(finish,reducedMotion()?0:750);},300);};
  raf=requestAnimationFrame(tick);
  return()=>{cancelAnimationFrame(raf);clearTimeout(timer);clearTimeout(hold);document.documentElement.style.removeProperty('overflow');};
 },[]);

 // live clock
 useEffect(()=>{const f=()=>setClock(formatClock(new Date()));f();const id=setInterval(f,1000);return()=>clearInterval(id);},[]);

 // smooth wheel scrolling (Lenis-style lerp) for mouse/trackpad users
 useEffect(()=>{
  if(reducedMotion()||!window.matchMedia('(pointer: fine)').matches)return;
  let raf=0;target.current=current.current=window.scrollY;
  const max=()=>document.documentElement.scrollHeight-window.innerHeight;
  const loop=()=>{current.current+=(target.current-current.current)*.1;if(Math.abs(target.current-current.current)<.5){current.current=target.current;smoothing.current=false;}window.scrollTo(0,current.current);if(smoothing.current)raf=requestAnimationFrame(loop);};
  const wheel=(e:WheelEvent)=>{if(e.ctrlKey||document.documentElement.style.overflow==='hidden')return;e.preventDefault();if(!smoothing.current)target.current=current.current=window.scrollY;target.current=Math.max(0,Math.min(max(),target.current+e.deltaY));if(!smoothing.current){smoothing.current=true;raf=requestAnimationFrame(loop);}};
  const sync=()=>{if(!smoothing.current)target.current=current.current=window.scrollY;};
  window.addEventListener('wheel',wheel,{passive:false});window.addEventListener('scroll',sync,{passive:true});
  return()=>{window.removeEventListener('wheel',wheel);window.removeEventListener('scroll',sync);cancelAnimationFrame(raf);};
 },[]);

 // stats count-up: progress from "top bottom" to "center center"
 useEffect(()=>{
  let pending=false;
  const update=()=>{pending=false;const ul=statsRef.current;if(!ul)return;const vh=window.innerHeight;
   setCounts([...ul.querySelectorAll<HTMLElement>('[data-i]')].map((el,i)=>{const r=el.getBoundingClientRect(),end=vh/2-r.height/2,p=Math.min(Math.max((vh-r.top)/(vh-end),0),1);return Math.round(p*statItems[i].v);}));};
  const on=()=>{if(!pending){pending=true;setTimeout(update,30);}};
  update();window.addEventListener('scroll',on,{passive:true});window.addEventListener('resize',on);
  return()=>{window.removeEventListener('scroll',on);window.removeEventListener('resize',on);};
  // eslint-disable-next-line react-hooks/exhaustive-deps
 },[]);

 // menu overlay: lock scroll, Escape closes
 useEffect(()=>{
  if(!menu)return;const k=(e:KeyboardEvent)=>{if(e.key==='Escape')closeMenu();};
  document.documentElement.style.overflow='hidden';window.addEventListener('keydown',k);
  return()=>{window.removeEventListener('keydown',k);document.documentElement.style.removeProperty('overflow');};
 },[menu]);
 function openMenu(){setMenuMounted(true);requestAnimationFrame(()=>requestAnimationFrame(()=>setMenu(true)));}
 function closeMenu(){setMenu(false);setTimeout(()=>setMenuMounted(false),450);}

 function go(href:string,e?:{preventDefault:()=>void}){
  if(!href.startsWith('#'))return;e?.preventDefault();
  const el=document.getElementById(href.slice(1));if(!el)return;
  const y=el.getBoundingClientRect().top+window.scrollY;
  smoothing.current=false; // hand over to native smooth scrolling; the wheel handler re-syncs on the next scroll
  window.scrollTo({top:y,behavior:reducedMotion()?'auto':'smooth'});
 }
 function step(n:number){setDir(n);setPrevSlide(slide);setSlide(s=>(s+n+samples.length)%samples.length);setTimeout(()=>setPrevSlide(null),450);}
 const askHref=(i:number)=>`/chat?product=${samples[i].p}&q=${encodeURIComponent(samples[i].title)}`;
 // question card rotates on its own after the intro; hovering, focusing or using the arrows pauses it
 const [paused,setPaused]=useState(false);
 const stepRef=useRef(step);stepRef.current=step;
 useEffect(()=>{if(!ready||paused||reducedMotion())return;const id=setInterval(()=>stepRef.current(1),5000);return()=>clearInterval(id);},[ready,paused]);

 const tagsFor=(id:string)=>Array.from(new Set(documents.filter(d=>d.product===id).map(d=>kindName[d.kind]).filter(Boolean)));
 const cards=[
  ...products.map(p=>({key:p.id,meta:`${p.category} — ${p.id}`,title:p.name,desc:`${p.description}。${p.version}。`,tags:tagsFor(p.id),href:`/chat?product=${p.id}`})),
  {key:'rates',meta:`工具 — ${stats.rates} 筆`,title:'費率試算',desc:'直接查表計算年繳保費，每個數字都能找到原始儲存格。',tags:['年繳保費','來源儲存格'],href:'/chat?tab=rates'},
 ];

 return <div className="lm">
  <a className="lm-skip" href="#lm-main">跳到主要內容</a>

  {showLoader&&<div className={'lm-loader'+(leaving?' out':'')} role="status" aria-label={'載入中 '+progress+'%'}>
   <div className="lm-loader-center"><div className="lm-loader-brand"><ShieldCheck/>保單知識客服</div><p>每一個答案，都有條款可以核對。</p></div>
   <div className="lm-progress"><div className="lm-track"><div className="lm-fill" style={{width:progress+'%'}}/></div><div className="lm-prow"><span>載入中</span><span className="num">{String(progress).padStart(3,'0')}</span></div></div>
  </div>}

  <Reveal as="header" className="lm-header" gate={ready} delay={150} from="translateY(-14px)">
   <div className="lm-shell lm-header-in">
    <a href="#home" className="lm-brand lm-hs" onClick={e=>go('#home',e)}><ShieldCheck/>保單知識客服</a>
    <nav className="lm-pnav" aria-label="主選單"><ul>{navItems.map(([l,h],i)=><li key={l}><a href={h} aria-current={i===0?'page':undefined} onClick={e=>go(h,e)}><span>{l}</span></a></li>)}</ul></nav>
    <div className="lm-hright">
     <div className="lm-chip lm-clock"><span className="lbl">本地時間</span><span className="t">{clock.time}</span><span className="sep">•</span><span className="d">{clock.date}</span></div>
     <button type="button" className="lm-chip lm-menu-btn" onClick={openMenu} aria-haspopup="dialog"><span><Menu/><span className="w">選單</span></span></button>
    </div>
   </div>
  </Reveal>

  <main id="lm-main">
   <section id="home" className="lm-hero">
    <LiquidReveal/>
    <div className="lm-vignette"/>
    <Reveal className="lm-wm-hero" gate={ready} delay={300} from="translateY(20px)" aria-hidden="true">POLICY DESK</Reveal>
    <div className="lm-shell lm-hero-grid">
     <div className="lm-hero-left">
      <Reveal className="lm-eyebrow" gate={ready} delay={200} from="translateY(10px)">三商品展示</Reveal>
      <Lines as="h1" className="lm-h1" lines={['每一個答案，','都有條款','可以核對。']} gate={ready} delay={250} stagger={120}/>
      <Reveal className="lm-rating" gate={ready} delay={650}><span className="lm-rating-icon"><ShieldCheck/></span><span>{products.length} 個商品 · {stats.documents} 份文件 · {stats.pdfPages} 頁可追溯</span></Reveal>
      <Reveal className="lm-ctas" gate={ready} delay={750}><Pill href="/chat" variant="dark" arrow="right">開始提問</Pill><Pill href="#products" variant="outlined" onClick={()=>go('#products',{preventDefault(){}})}>看商品</Pill></Reveal>
     </div>
     <div className="lm-hero-right">
      <Reveal className="lm-hcard" gate={ready} delay={400} from="translateY(16px) scale(.96)">
       <div className="lm-hc-row" onMouseEnter={()=>setPaused(true)} onMouseLeave={()=>setPaused(false)} onFocus={()=>setPaused(true)} onBlur={()=>setPaused(false)}>
        <a className="lm-hc-tile" href={askHref(slide)} aria-label={'直接問這題：'+samples[slide].title}><MessageSquare/></a>
        <div className="lm-hc-panel">
         <a className="lm-hc-slot" href={askHref(slide)} aria-live="polite" aria-label={'直接問這題：'+samples[slide].title}>
          {prevSlide!==null&&<div key={'p'+prevSlide} className={'lm-hc-item leave '+(dir>0?'up':'down')}><p className="cap">{samples[prevSlide].caption}</p><p className="title">{samples[prevSlide].title}</p></div>}
          <div key={'c'+slide} className={'lm-hc-item enter '+(prevSlide!==null?(dir>0?'from-down':'from-up'):'')}><p className="cap">{samples[slide].caption}</p><p className="title">{samples[slide].title}</p></div>
         </a>
         <div className="lm-hc-bottom"><div className="lm-dots">{samples.map((_,i)=><span key={i} className={i===slide?'on':''}/>)}</div>
          <div className="lm-hc-btns"><button type="button" className="prev" aria-label="上一題" onClick={e=>{e.preventDefault();e.stopPropagation();setPaused(true);step(-1);}}><ArrowRight/></button><button type="button" aria-label="下一題" onClick={e=>{e.preventDefault();e.stopPropagation();setPaused(true);step(1);}}><ArrowRight/></button></div></div>
        </div>
       </div>
      </Reveal>
      <Reveal className="lm-partners" gate={ready} delay={550} from="translateY(14px)">
       <p className="lbl">資料來源</p>
       <ul>{[...products.map(p=>p.short),'正式條款','商品 DM','費率表'].map(n=><li key={n}><span><CircleDot/>{n}</span></li>)}</ul>
      </Reveal>
     </div>
    </div>
    <Reveal className="lm-shell lm-statusbar" gate={ready} delay={900} from="none"><span>資料整理於 2026.10.18</span><span className="mid">依正式條款回答・附頁碼</span><span className="scroll">往下看看 <span aria-hidden="true">↓</span></span></Reveal>
   </section>

   <section id="about" className="lm-about">
    <div className="lm-shell lm-about-in">
     <div className="lm-globe">
      <BookOpen className="lm-globe-bg" strokeWidth={1}/>
      <div className="lm-eyebrow">關於這個客服</div>
      <Reveal className="lm-globe-note"><BookOpen/><span>依提供文件版本查詢，個案理賠仍需確認契約與事實。</span></Reveal>
     </div>
     <div className="lm-statement">
      <Chars text="把三張保單的條款、DM 與費率，整理成可以直接問的資料。" muted="每個回答都附上條款頁碼，讓你自己核對原文。"/>
      <Reveal className="lm-about-foot" delay={200}>
       <div><p className="lbl">快速前往</p><div className="lm-socials">
        <a href="/chat" className="accent" aria-label="客服問答"><MessageSquare/></a>
        <a href="/chat?tab=library" aria-label="文件資料庫"><Files/></a>
        <a href="/chat?tab=rates" aria-label="費率試算"><Calculator/></a>
       </div></div>
       <Pill href="/chat" variant="outlined" arrow="right">開始提問</Pill>
      </Reveal>
     </div>
    </div>
   </section>

   <section className="lm-band" aria-label="三個步驟">
    <ul className="lm-shell">
     {bandSteps.map((x,i)=><Reveal as="li" key={x.t} delay={i*120} from="translateY(28px)">
      <a className={'lm-tile '+x.c} href={x.href} aria-label={x.n?`${x.n} ${x.t}：${x.d}`:x.t}>
       {x.n&&<span className="n">{x.n}</span>}
       <span className="t">{x.t}{!x.n&&<ArrowRight className="cta-arrow"/>}</span>
       {x.d&&<span className="d">{x.d}</span>}
       {x.n&&<span className="go"><ArrowUpRight/></span>}
      </a>
     </Reveal>)}
    </ul>
   </section>

   <section id="products" className="lm-works">
    <div className="lm-shell lm-works-in">
     <Reveal className="lm-eyebrow boxed">商品</Reveal>
     <Lines className="lm-works-h" lines={['本次展示商品']} delay={120}/>
     <ul className="lm-cards">{cards.map((c,i)=><Reveal as="li" key={c.key} delay={i*90} from="translateY(48px)" className="slow">
      <a href={c.href} aria-label={c.title}><article className="lm-card">
       <div className="lm-card-meta"><span>{c.meta}</span><span className="lm-card-badge"><ArrowUpRight/></span></div>
       <div className="lm-card-wm" aria-hidden="true"><span><ShieldCheck strokeWidth={1.5}/><sup>®</sup></span></div>
       <div className="lm-card-bottom"><h3>{c.title}</h3><p>{c.desc}</p><div className="lm-tags">{c.tags.map(t=><span key={t}>{t}</span>)}</div></div>
      </article></a>
     </Reveal>)}</ul>
    </div>
   </section>

   <section id="features" className="lm-services">
    <div className="lm-shell lm-services-in">
     <Reveal className="lm-eyebrow">功能</Reveal>
     <Lines className="lm-services-h" lines={['你可以這樣用']} delay={120}/>
     <ul className="lm-srows">{features.map((f,i)=><Reveal as="li" key={f.n} delay={i*80} from="translateY(24px)">
      <a href={f.href}><div className="lm-srow"><span className="idx">{f.n}</span><h3>{f.t}</h3><p>{f.d}</p><span className="badge"><ArrowUpRight/></span></div></a>
     </Reveal>)}</ul>
    </div>
   </section>

   <section className="lm-stats" aria-label="資料範圍">
    <div className="lm-shell lm-stats-in">
     <Reveal className="lm-panel slow" from="translateY(40px) scale(.99)">
      <div className="lm-eyebrow light">資料範圍</div>
      <Lines className="lm-panel-h" lines={['每個答案，','都找得到出處。']} delay={120}/>
      <ul className="lm-sgrid" ref={statsRef}>{statItems.map((s,i)=><Reveal as="li" key={s.l} delay={i*90} from="translateY(20px)"><div className="num" data-i={i}>{counts[i]}{s.s}</div><p>{s.l}</p></Reveal>)}</ul>
     </Reveal>
    </div>
   </section>
  </main>

  <footer className="lm-footer">
   <div className="lm-shell lm-foot-in">
    <div className="lm-foot-cta"><Lines lines={['有保單問題？','現在就問。']} stagger={100}/><Pill href="/chat" variant="light" arrow="up-right">開始提問</Pill></div>
    <div className="lm-fcols">
     <div><div className="lm-fbrand"><ShieldCheck/>保單知識客服</div><p className="lm-ftag">查詢保障、給付條件與費率，逐項核對條款來源。</p></div>
     <div className="lm-fcol"><h4>功能</h4><ul>{features.map(f=><li key={f.n}><a className="lm-alink" href={f.href}><span>{f.t}</span></a></li>)}</ul></div>
     <div className="lm-fcol"><h4>商品</h4><ul>{products.map(p=><li key={p.id}><a className="lm-alink" href={`/chat?product=${p.id}`}><span>{p.short}</span></a></li>)}</ul></div>
     <div className="lm-fcol"><h4>使用提醒</h4><ul className="plain"><li>公開展示網站</li><li>請勿輸入個人資料</li><li>個案理賠以契約為準</li></ul></div>
    </div>
    <div className="lm-legal"><span>© 2026 保單知識客服・三商品展示</span><div className="links"><a className="lm-alink" href="/chat?tab=library"><span>文件資料庫</span></a><a className="lm-alink" href="/chat?tab=settings"><span>連線與設定</span></a></div></div>
   </div>
   <div className="lm-wm-foot" aria-hidden="true">POLICY DESK</div>
  </footer>

  {menuMounted&&<div className={'lm-navmenu'+(menu?' open':'')} role="dialog" aria-modal="true" aria-label="選單">
   <div className="lm-shell lm-nm-top"><div className="lm-brand"><ShieldCheck/>保單知識客服</div><button type="button" className="lm-nm-close" autoFocus onClick={closeMenu}><X/>關閉</button></div>
   <nav className="lm-shell lm-nm-nav" aria-label="選單連結"><ul>{navItems.map(([l,h],i)=><li key={l}><a className="lm-nm-item" href={h} style={{transitionDelay:i*45+80+'ms'}} onClick={e=>{if(h.startsWith('#')){e.preventDefault();closeMenu();setTimeout(()=>go(h),460);}}}><span className="n">0{i+1}</span><span className="l">{l}</span></a></li>)}</ul></nav>
   <div className="lm-shell lm-nm-bottom"><span>本地時間 — {clock.time}</span><a href="/chat">開始提問 →</a></div>
  </div>}
 </div>;
}
