import data from '@/lib/knowledge.json';
import {validateQueryRequest} from '@/lib/request-validation.mjs';
import {resolveProduct,sourceAnswer,parseRateQuestion,lookupRate,buildClaudeRequest,parseClaudeResponse} from '@/lib/engine.mjs';
import {getAIConfig} from '@/lib/ai-config.mjs';
import {buildGeminiRequest,parseGeminiResponse,withoutThinking} from '@/lib/gemini.mjs';
import {requestGemini} from '@/lib/gemini-failover.mjs';
import {createAnswerCache} from '@/lib/answer-cache.mjs';
export const dynamic='force-dynamic';
// repeated first-turn questions (e.g. the landing-page samples) are answered from memory: instant, and no AI quota used
const answerCache=createAnswerCache();
const WINDOW_MS=60_000,PER_IP=5;
const DAILY_CAP=Number(process.env.AI_DAILY_CAP||process.env.CLAUDE_DAILY_CAP||200);
const hits=new Map<string,number[]>();
let usageDay='',usageCount=0;
function checkLimit(ip:string):'daily'|'rate'|null{
 const now=Date.now(),d=new Date(now).toISOString().slice(0,10);
 if(d!==usageDay){usageDay=d;usageCount=0;}
 if(usageCount>=DAILY_CAP)return 'daily';
 const arr=(hits.get(ip)||[]).filter(t=>now-t<WINDOW_MS);
 if(arr.length>=PER_IP)return 'rate';
 arr.push(now);hits.set(ip,arr);
 if(hits.size>5000)hits.clear();
 usageCount++;
 return null;
}
// When the AI answer times out, fails citation validation, or the connection drops, show the matching clause text
// instead of an error (same as the 429/503 fallbacks). A 2026-10-21 audit of 10 live questions hit this 3 times.
function aiFallback(question:string,product:string,label:string,e:unknown){
 const timeout=e instanceof Error&&e.name==='TimeoutError',unverified=e instanceof Error&&/引用|限制|文字|格式/.test(e.message);
 const warning=timeout?`${label} 回覆逾時，已改為文件原文查詢；以下不是 AI 生成回答，可稍後再問一次。`
  :unverified?`${label} 的回答沒有通過條款引用檢查，為避免提供無依據的內容，已改為文件原文查詢；以下不是 AI 生成回答。`
  :`暫時無法連線至 ${label}，已改為文件原文查詢；以下不是 AI 生成回答。`;
 return {...sourceAnswer(question,product,data),warning,fallbackReason:timeout?'AI_TIMEOUT':unverified?'AI_UNVERIFIED':'AI_UNREACHABLE'};
}
const json=(body:unknown,status=200)=>Response.json(body,{status,headers:{'Cache-Control':'no-store'}});
export async function POST(request:Request){
 try{return await handleQuery(request);}catch{return json({error:'伺服器處理失敗，請稍後再試。'},500);}
}
async function handleQuery(request:Request){
 const origin=request.headers.get('origin');if(origin&&origin!==new URL(request.url).origin)return json({error:'來源不符。'},403);
 let input;try{const raw=await request.text();if(raw.length>20000)return json({error:'請縮短問題。'},413);input=JSON.parse(raw);}catch{return json({error:'問題格式不正確。'},400);}
 const validation=validateQueryRequest(input);
 if(validation.error||!validation.value)return json({error:validation.error},400);
 const {question,product,mode,history}=validation.value;
 const resolved=resolveProduct(question,product,data);if(resolved.error)return json({mode:'clarify',answer:resolved.error,sources:[]});
 if(/保費|費率|報價/.test(question)&&/\d+\s*歲/.test(question)){
  const result=lookupRate({product:resolved.product,...parseRateQuestion(question)},data);
  if(result.error)return json({mode:'clarify',answer:result.error+' 可使用「費率試算」填寫完整條件。',sources:[]});
  return json({mode:'calculation',product:resolved.product,answer:`依提供費率表，每萬元保額年繳費率為 ${result.rate} 元。保額 ${result.amount.toLocaleString()} 元的年繳試算為 ${result.annual.toLocaleString()} 元。\n${result.note}`,rate:result,sources:[]});
 }
 if(mode==='documents')return json(sourceAnswer(question,resolved.product,data));
 const {key,backupKey,provider,model,label}=getAIConfig();if(!key)return json({error:`尚未設定 ${label} API 金鑰。文件查詢與費率試算可先使用。`,code:'KEY_MISSING'},503);
 const cacheKey={provider,model,product:resolved.product,question},cacheable=!history||history.length===0;
 const cached=cacheable?answerCache.get(cacheKey):null;
 if(cached)return json({...cached,cached:true});
 // 只信任所在平台會覆寫的標頭：Vercel 覆寫 x-real-ip，Cloudflare 覆寫 cf-connecting-ip；其餘可由訪客偽造。
 const h=request.headers,ip=(process.env.VERCEL?h.get('x-real-ip'):h.get('cf-connecting-ip'))||h.get('x-forwarded-for')?.split(',')[0].trim()||'unknown';
 const limited=checkLimit(ip);
 if(limited)return json({error:limited==='daily'?'今日 AI 問答額度已用完，請改用文件查詢或明日再試。':'請求過於頻繁，請稍後再試。',code:'RATE_LIMITED'},429);
 if(provider==='gemini'){
  const prepared=buildGeminiRequest(question,resolved.product,history,data);
  try{
   const signal=AbortSignal.timeout(55000),started=Date.now();
   let {response:result,usedBackup}=await requestGemini({model,key,backupKey,body:prepared.body,signal});
   // a model that does not accept thinkingLevel answers 400; ask once more without it rather than failing
   if(result.status===400&&prepared.body.generationConfig.thinkingConfig)({response:result,usedBackup}=await requestGemini({model,key,backupKey,body:withoutThinking(prepared.body),signal}));
   if(result.status===429)return json({...sourceAnswer(question,resolved.product,data),warning:'Gemini 目前可用的額度或速率皆受限，已改為文件原文查詢；以下不是 AI 生成回答。',fallbackReason:'AI_QUOTA'});
   if(result.status===500||result.status===503)return json({...sourceAnswer(question,resolved.product,data),warning:'Gemini 服務目前忙碌（Google 端容量不足），已改為文件原文查詢；以下不是 AI 生成回答，可稍後再問一次。',fallbackReason:'AI_UNAVAILABLE'});
   if(!result.ok){const map:Record<number,string>={400:'Gemini 請求或金鑰設定無效，請管理員檢查設定。',401:'Gemini 金鑰無效，請更新伺服器設定。',403:'Gemini 帳號、金鑰或地區無權使用此服務。',404:'Gemini 模型不可用，請檢查 GEMINI_MODEL。',429:'Gemini 額度或速率受限，請稍後重試並檢查帳號。',503:'Gemini 服務忙碌，請稍後重試。'};return json({error:map[result.status]||'Gemini 服務請求失敗，請稍後重試。'},502);}
   const payload=await result.json() as {usageMetadata?:{candidatesTokenCount?:number;thoughtsTokenCount?:number};candidates?:{finishReason?:string}[]},usage=payload?.usageMetadata;
   // timing only: no key, question or answer text is logged
   console.log(JSON.stringify({event:'gemini_answer',ms:Date.now()-started,product:resolved.product,finish:payload?.candidates?.[0]?.finishReason,outTokens:usage?.candidatesTokenCount,thinkTokens:usage?.thoughtsTokenCount,backup:usedBackup}));
   const answer={...parseGeminiResponse(payload,prepared.sources),product:resolved.product};
   if(cacheable&&!String(answer.mode).endsWith('unverified'))answerCache.set(cacheKey,answer);
   return json({...answer,...(usedBackup?{serviceNotice:'主用服務暫時受限，本次已使用備用服務回答。'}:{})});
  }catch(e){console.log(JSON.stringify({event:'gemini_fallback',product:resolved.product,reason:e instanceof Error?e.name:'unknown'}));return json(aiFallback(question,resolved.product,'Gemini',e));}
 }
 const prepared=buildClaudeRequest(question,resolved.product,history,data,model);
 try{
  const result=await fetch('https://api.anthropic.com/v1/messages',{method:'POST',headers:{'content-type':'application/json','x-api-key':key,'anthropic-version':'2023-06-01'},body:JSON.stringify(prepared.body),signal:AbortSignal.timeout(55000)});
  if(!result.ok){const map:Record<number,string>={401:'Claude 金鑰無效，請更新伺服器設定。',403:'Claude 帳號無權使用此服務或模型。',404:'模型不可用，請檢查 ANTHROPIC_MODEL。',429:'Claude 額度或速率受限，請稍後重試並檢查帳號。',529:'Claude 服務忙碌，請稍後重試。'};return json({error:map[result.status]||'Claude 服務請求失敗，請稍後重試。'},502);}
  const answer={...parseClaudeResponse(await result.json(),prepared.sources),product:resolved.product};
  if(cacheable&&!String(answer.mode).endsWith('unverified'))answerCache.set(cacheKey,answer);
  return json(answer);
 }catch(e){return json(aiFallback(question,resolved.product,'Claude',e));}
}
