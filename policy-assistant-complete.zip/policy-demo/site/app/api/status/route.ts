import {getAIConfig} from '@/lib/ai-config.mjs';
export const dynamic='force-dynamic';
export async function GET(){
 try{const {key,backupKey,provider,model,label}=getAIConfig();return Response.json({configured:!!key,provider,model,label,backupConfigured:!!backupKey},{headers:{'Cache-Control':'no-store'}});}
 catch{return Response.json({configured:false,error:'AI 服務設定無效。'},{status:503,headers:{'Cache-Control':'no-store'}});}
}
