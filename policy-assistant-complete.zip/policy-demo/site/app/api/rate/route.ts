import data from '@/lib/knowledge.json';
import {lookupRate} from '@/lib/engine.mjs';
export async function POST(request:Request){
 if(request.headers.get('origin')&&request.headers.get('origin')!==new URL(request.url).origin)return Response.json({error:'來源不符。'},{status:403});
 try{const raw=await request.text();if(raw.length>1000)return Response.json({error:'輸入過長。'},{status:413});return Response.json(lookupRate(JSON.parse(raw),data),{headers:{'Cache-Control':'no-store'}});}catch{return Response.json({error:'輸入格式不正確。'},{status:400});}
}
