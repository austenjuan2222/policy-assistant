import Landing from './landing';
import knowledge from '@/lib/knowledge.json';
export default function Home(){return <Landing products={knowledge.products} documents={knowledge.documents} stats={knowledge.stats}/>;}
