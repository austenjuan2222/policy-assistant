@echo off
chcp 65001 >nul
cd /d "%~dp0"
set "NODE=C:\Users\TESTER\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe"
set "LOG=%~dp0check-log.txt"
echo === started %date% %time% === > "%LOG%"
echo [1/3] unit tests >> "%LOG%"
"%NODE%" --test tests/engine.test.mjs tests/request-validation.test.mjs >> "%LOG%" 2>&1
echo exit code: %errorlevel% >> "%LOG%"
echo [2/3] typecheck >> "%LOG%"
"%NODE%" node_modules/typescript/bin/tsc --noEmit >> "%LOG%" 2>&1
echo exit code: %errorlevel% >> "%LOG%"
echo [3/3] build >> "%LOG%"
"%NODE%" scripts/run-framework.mjs build >> "%LOG%" 2>&1
echo exit code: %errorlevel% >> "%LOG%"
echo === finished %date% %time% === >> "%LOG%"
echo.
echo Done. Results saved to check-log.txt
pause
