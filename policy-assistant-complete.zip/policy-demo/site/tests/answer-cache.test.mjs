import test from 'node:test';
import assert from 'node:assert/strict';
import { createAnswerCache, normalizeQuestion } from '../lib/answer-cache.mjs';

const parts = { provider: 'gemini', model: 'm', product: 'SCB', question: '安心加倍防癌的等待期間多久？' };

test('normalizes spacing, width and trailing punctuation', () => {
  assert.equal(normalizeQuestion(' 安心加倍防癌 的等待期間多久？ '), normalizeQuestion('安心加倍防癌的等待期間多久?'));
});

test('returns a stored answer for the same question', () => {
  const cache = createAnswerCache();
  cache.set(parts, { answer: 'A' });
  assert.deepEqual(cache.get({ ...parts, question: '安心加倍防癌的等待期間多久' }), { answer: 'A' });
});

test('keys on product, provider and model', () => {
  const cache = createAnswerCache();
  cache.set(parts, { answer: 'A' });
  assert.equal(cache.get({ ...parts, product: 'RAC' }), null);
  assert.equal(cache.get({ ...parts, model: 'other' }), null);
  assert.equal(cache.get({ ...parts, provider: 'claude' }), null);
});

test('expires entries after the TTL', () => {
  let t = 0;
  const cache = createAnswerCache({ ttlMs: 1000, now: () => t });
  cache.set(parts, { answer: 'A' });
  t = 1001;
  assert.equal(cache.get(parts), null);
  assert.equal(cache.size, 0);
});

test('evicts the least recently used entry when full', () => {
  const cache = createAnswerCache({ maxEntries: 2 });
  cache.set({ ...parts, question: 'q1' }, 1);
  cache.set({ ...parts, question: 'q2' }, 2);
  cache.get({ ...parts, question: 'q1' });
  cache.set({ ...parts, question: 'q3' }, 3);
  assert.equal(cache.get({ ...parts, question: 'q2' }), null);
  assert.equal(cache.get({ ...parts, question: 'q1' }), 1);
  assert.equal(cache.get({ ...parts, question: 'q3' }), 3);
});

test('ignores empty questions', () => {
  const cache = createAnswerCache();
  cache.set({ ...parts, question: ' ？ ' }, 'x');
  assert.equal(cache.size, 0);
});
