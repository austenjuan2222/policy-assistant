import test from 'node:test';
import assert from 'node:assert/strict';
import data from '../lib/knowledge.json' with {type:'json'};
import {buildGeminiRequest,selectPages} from '../lib/gemini.mjs';

const terms=p=>data.chunks.filter(c=>c.product===p&&c.kind==='terms');

test('long policies send at most 14 relevant pages to Gemini', () => {
  for (const [p, q] of [['RAC', '安新 100 意外住院如何給付？'], ['RAE2', '享安心什麼情況可以豁免保費？']]) {
    const r = buildGeminiRequest(q, p, [], data);
    assert.ok(r.sources.length <= 14, `${p}: ${r.sources.length} pages`);
    assert.ok(r.sources.length < terms(p).length);
    assert.ok(r.sources.every(s => s.product === p && s.kind === 'terms'));
  }
});

test('selected pages include the best match, the definitions page and the exclusions', () => {
  const all = terms('RAC');
  const picked = selectPages('安新 100 滿期保險金怎麼給付？', 'RAC', [], data, all).map(s => s.page);
  assert.ok(picked.includes(5), 'page with 滿期保險金');
  assert.ok(all.filter(c => /除外責任/.test(c.text)).every(c => picked.includes(c.page)), 'exclusion pages');
});

test('short policies are sent whole', () => {
  const all = terms('SCB');
  assert.equal(selectPages('等待期間多久', 'SCB', [], data, all).length, all.length);
});

test('the request body only quotes the selected pages', () => {
  const r = buildGeminiRequest('安新 100 骨折怎麼給付？', 'RAC', [], data);
  const docs = JSON.parse(r.body.contents[0].parts[0].text).documents;
  assert.deepEqual(docs.map(d => d.source_id), r.sources.map(s => s.id));
});

import {thinkingConfig,withoutThinking} from '../lib/gemini.mjs';
test('asks for light reasoning by default and can be turned off', () => {
  assert.deepEqual(thinkingConfig({}), {thinkingConfig:{thinkingLevel:'minimal'}});
  assert.deepEqual(thinkingConfig({GEMINI_THINKING_LEVEL:'off'}), {});
  assert.deepEqual(thinkingConfig({GEMINI_THINKING_LEVEL:'nonsense'}), {});
  const body = buildGeminiRequest('等待期間多久', 'SCB', [], data).body;
  assert.equal(body.generationConfig.thinkingConfig.thinkingLevel, 'minimal');
  const retry = withoutThinking(body);
  assert.equal(retry.generationConfig.thinkingConfig, undefined);
  assert.equal(retry.generationConfig.responseMimeType, 'application/json');
});

test('output is capped so long "how much" answers finish before the 55s route timeout', () => {
  const {body} = buildGeminiRequest('安心加倍防癌罹患癌症可以領多少？', 'SCB', [], data);
  assert.equal(body.generationConfig.maxOutputTokens, 3072);
  assert.equal(body.generationConfig.responseJsonSchema.properties.blocks.maxItems, 8);
  assert.match(body.systemInstruction.parts[0].text, /最多 6 段/);
});
