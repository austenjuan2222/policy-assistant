[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$node = 'C:\Users\TESTER\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe'
$deploy = Join-Path $PSScriptRoot '..\..\tools\deploy-vercel.mjs'

function Read-Secret($label) {
  $secure = Read-Host $label -AsSecureString
  $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
  try { return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr) }
  finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) }
}

if (-not $env:VERCEL_TOKEN) {
  Write-Host ''
  Write-Host 'Step 1/2: create a token at https://vercel.com/account/tokens, then paste it below (hidden).'
  $env:VERCEL_TOKEN = Read-Secret 'Vercel token'
}
if ($args -contains '--with-gemini-key') {
  Write-Host ''
  Write-Host 'Step 2/3: paste your MAIN Gemini API key (hidden). Press Enter to skip.'
  $env:AI_PROVIDER_INPUT = 'gemini'
  $env:AI_KEY_INPUT = Read-Secret 'Gemini API key (main)'
  if ($env:AI_KEY_INPUT) {
    Write-Host ''
    Write-Host 'Step 3/3: paste your SECOND Gemini API key as backup (hidden). Press Enter to skip.'
    $env:AI_BACKUP_KEY_INPUT = Read-Secret 'Gemini API key (backup)'
  }
} elseif ($args -contains '--with-anthropic-key') {
  Write-Host ''
  Write-Host 'Step 2/2: paste your Anthropic API key (hidden). Press Enter to skip.'
  $env:AI_PROVIDER_INPUT = 'claude'
  $env:AI_KEY_INPUT = Read-Secret 'Anthropic API key'
}
try {
  & $node $deploy @($args | Where-Object { $_ -notlike '--with-*-key' })
} finally {
  Remove-Item Env:AI_KEY_INPUT, Env:AI_BACKUP_KEY_INPUT, Env:AI_PROVIDER_INPUT, Env:VERCEL_TOKEN -ErrorAction SilentlyContinue
}
