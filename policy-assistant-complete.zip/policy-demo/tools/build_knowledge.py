from pathlib import Path
import json,re,shutil,unicodedata
ROOT=Path(__file__).resolve().parents[2]
BASE=ROOT/'policy-demo'
docs=json.loads((BASE/'data/sources.json').read_text(encoding='utf-8'))
versions={'d01':'條款備查 2021-04-16','d02':'費率版本未標示；僅 20 年期 40–65 歲','d03':'DM 2024-01-01／15 年期','d04':'DM 2023-07-01／20 年期','d05':'DM 2024-07-01／15 年期','d06':'DM 2022-09-02／15 年期','d07':'DM 2022-09-02／20 年期','d08':'費率檔名 2021-07-01','d09':'費率版本未標示','d10':'費率版本未標示','d11':'條款備查 2023-09-01','d12':'條款備查 2021-07-01'}
products=[{'id':'RAC','name':'安新 100 終身保險','short':'安新 100','category':'意外保障','description':'意外住院、手術、失能及滿期給付','terms':'d12','version':versions['d12'],'color':'green'}, {'id':'RAE2','name':'享安心終身保險','short':'享安心','category':'意外保障','description':'意外醫療、失能及符合條件的保費豁免','terms':'d11','version':versions['d11'],'color':'blue'}, {'id':'SCB','name':'安心加倍防癌定期保險','short':'安心加倍防癌','category':'癌症保障','description':'癌症給付、特定癌症及保費豁免','terms':'d01','version':versions['d01'],'color':'gold'}]
chunks=[]; rates=[]; catalog=[]
pub=BASE/'site/public/documents';pub.mkdir(parents=True,exist_ok=True)
for d in docs:
    cat={k:d[k] for k in ['id','name','product','kind','sha256']}
    cat.update(version=versions[d['id']],pages=len(d['pages']),url=f"/documents/{d['id']}{Path(d['name']).suffix}")
    # Only PDF originals are published. Excel internal/hidden tabs stay local.
    if d['pages']:
        shutil.copyfile(ROOT/d['name'],pub/(d['id']+'.pdf'))
        for p in d['pages']:
            text=unicodedata.normalize('NFKC',p['text'])
            text=re.sub(r'[ \t]+',' ',text).strip()
            chunks.append({'id':f"{d['id']}-p{p['page']}",'docId':d['id'],'product':d['product'],'kind':d['kind'],'page':p['page'],'text':text,'title':d['name'],'version':versions[d['id']]})
    else:
        cat['url']=None
        cat['scope']='僅匯入主要費率表；成本、隱藏比較及計算器區域未發布'
        s=d['sheets'][0]
        for row in s['rows']:
            vals={re.sub(r'\d','',c['cell']):c for c in row}
            if d['product']=='SCB':
                if not all(k in vals for k in ['B','C','D','E','F']):continue
                # Exclude the workbook's interactive calculator row.
                if int(re.search(r'\d+',vals['E']['cell'])[0])<8:continue
                if vals['D']['value'] not in ['M','F']:continue
                rates.append({'product':'SCB','age':int(vals['E']['value']),'sex':vals['D']['value'],'term':int(vals['C']['value']),'rate':vals['F']['value'],'docId':d['id'],'sheet':s['name'],'cell':vals['F']['cell'],'unit':10000})
            else:
                for ac,mc,fc,term in [('A','B','C',15),('E','F','G',20)]:
                    if not all(k in vals for k in [ac,mc,fc]):continue
                    av=vals[ac]['value']
                    if av=='15足':age=15
                    elif isinstance(av,(int,float)) and 15<=av<=100:age=int(av)
                    else:continue
                    for sex,c in [('M',mc),('F',fc)]:
                        if isinstance(vals[c]['value'],(float,int)):
                            rates.append({'product':d['product'],'age':age,'ageNote':'15 足歲' if av=='15足' else '', 'sex':sex,'term':term,'rate':vals[c]['value'],'docId':d['id'],'sheet':s['name'],'cell':vals[c]['cell'],'unit':10000})
    catalog.append(cat)
issues=[{'product':'SCB','title':'15 年期費率尚缺','detail':'DM 為 15 年期，但 Excel 正式表格僅有 20 年期、40–65 歲。15 年期報價需補件。'}, {'product':'RAE2','title':'DM 與條款日期不同','detail':'20 年期 DM 日期為 2023-07-01，條款備查為 2023-09-01。demo 以所附條款回答，適用契約版本需公司確認。'}, {'product':'ALL','title':'展示資料尚待業務覆核','detail':'條款樣本不代表個別客戶契約；保戶批註、附約與實際生效資料尚未納入。'}, {'product':'ALL','title':'尚未連接 Claude','detail':'未提供 API 金鑰。文件查詢與費率計算可使用，Claude 真實回答品質待連線驗證。'}]
out={'products':products,'documents':catalog,'chunks':chunks,'rates':rates,'issues':issues,'builtAt':'2026-10-18','stats':{'documents':len(docs),'pdfPages':len(chunks),'rates':len(rates)}}
dest=BASE/'site/lib';dest.mkdir(parents=True,exist_ok=True)
(dest/'knowledge.json').write_text(json.dumps(out,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
(BASE/'data/catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2),encoding='utf-8')
print(out['stats'])
print('SCB terms:',sorted(set(r['term'] for r in rates if r['product']=='SCB')))
