from pathlib import Path
import json, hashlib
from pypdf import PdfReader
from openpyxl import load_workbook

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'policy-demo' / 'data'
OUT.mkdir(parents=True, exist_ok=True)
docs=[]
for p in sorted(ROOT.iterdir()):
    if p.suffix.lower() not in ('.pdf','.xlsx'): continue
    product='SCB' if '防癌' in p.name else 'RAC' if '安新' in p.name else 'RAE2'
    kind='terms' if '條款' in p.name else 'rates' if '費率' in p.name else 'dm'
    d={'id':f'd{len(docs)+1:02}', 'name':p.name,'product':product,'kind':kind,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'pages':[],'sheets':[]}
    if p.suffix.lower()=='.pdf':
        d['pages']=[{'page':i+1,'text':page.extract_text()} for i,page in enumerate(PdfReader(p).pages)]
    else:
        wb=load_workbook(p,data_only=True)
        for s in wb:
            rows=[]
            for row in s:
                vals=[{'cell':c.coordinate,'value':c.value} for c in row if c.value is not None]
                if vals: rows.append(vals)
            d['sheets'].append({'name':s.title,'state':s.sheet_state,'rows':rows})
    docs.append(d)
(OUT/'sources.json').write_text(json.dumps(docs,ensure_ascii=False,indent=2),encoding='utf-8')
for d in docs:
    text='\n\n'.join(f"PAGE {p['page']}\n{p['text']}" for p in d['pages'])
    if d['sheets']: text=json.dumps(d['sheets'],ensure_ascii=False,indent=2)
    (OUT/(d['id']+'.txt')).write_text(text,encoding='utf-8')
    print(d['id'],d['name'],len(d['pages']),[(s['name'],s['state'],len(s['rows'])) for s in d['sheets']])
