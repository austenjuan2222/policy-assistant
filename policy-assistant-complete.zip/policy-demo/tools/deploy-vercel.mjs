// 把 policy-demo/site 部署到 Vercel（production）。
// 用法（PowerShell）：
//   $env:VERCEL_TOKEN = '<你在 vercel.com/account/tokens 建立的 token>'
//   & 'C:\Users\TESTER\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' tools\deploy-vercel.mjs
// 選用：$env:VERCEL_TEAM_ID = 'team_...'（token 屬於 team 時才需要）
// 加 --dry-run 只列出會上傳的檔案，不連線。
import { createHash } from 'node:crypto';
import { readFile, readdir, stat } from 'node:fs/promises';
import { join, relative, sep } from 'node:path';
import { fileURLToPath } from 'node:url';

const SITE = fileURLToPath(new URL('../site/', import.meta.url));
const PROJECT = 'policy-demo';
const DRY = process.argv.includes('--dry-run');
const TOKEN = process.env.VERCEL_TOKEN || '';
// Austen 帳號的預設 team（slug austen5）；第一次部署就是建在這裡。
const TEAM = process.env.VERCEL_TEAM_ID || 'team_ob7ilC9rDfahM8HmoBeK0uAA';

const SKIP_DIRS = new Set(['node_modules', '.next', 'dist', '.wrangler', '.vinext', '.sites-runtime', '.git', '.vercel', 'coverage']);
const SKIP_FILES = new Set(['tsconfig.tsbuildinfo', 'check-log.txt', 'run-checks.bat', '給Codex的發布指令.txt', 'next-env.d.ts', 'scripts/deploy-vercel.ps1']);
// build/ 只保留 .gitignore 允許的原始碼
const BUILD_KEEP = new Set(['connector-preview-plugin.mjs', 'connector-preview-worker.mjs', 'sites-vite-plugin.LICENSE', 'sites-vite-plugin.ts', 'sites-worker.ts']);

async function walk(dir, out = []) {
  for (const ent of await readdir(dir, { withFileTypes: true })) {
    const full = join(dir, ent.name);
    const rel = relative(SITE, full).split(sep).join('/');
    if (ent.isDirectory()) {
      if (SKIP_DIRS.has(ent.name) && !rel.includes('/')) continue;
      if (ent.name === 'node_modules') continue;
      await walk(full, out);
    } else if (ent.isFile()) {
      if (SKIP_FILES.has(rel) || ent.name.startsWith('.env')) continue;
      if (rel.startsWith('build/') && !BUILD_KEEP.has(rel.slice(6))) continue;
      out.push({ full, rel });
    }
  }
  return out;
}

const api = (path) => `https://api.vercel.com${path}${TEAM ? (path.includes('?') ? '&' : '?') + 'teamId=' + encodeURIComponent(TEAM) : ''}`;
const auth = () => ({ Authorization: `Bearer ${TOKEN}` });

async function upload(f) {
  const res = await fetch(api('/v2/files'), {
    method: 'POST',
    headers: { ...auth(), 'Content-Type': 'application/octet-stream', 'x-vercel-digest': f.sha, 'Content-Length': String(f.size) },
    body: f.buf,
  });
  if (!res.ok) throw new Error(`上傳失敗 ${f.rel}：HTTP ${res.status} ${await res.text()}`);
}

async function printLogs(id) {
  const res = await fetch(api(`/v3/deployments/${id}/events?builds=1&direction=forward&limit=-1`), { headers: auth() });
  if (!res.ok) { console.error(`讀取建置紀錄失敗：HTTP ${res.status} ${await res.text()}`); return; }
  const raw = await res.text();
  let events = [];
  try { events = JSON.parse(raw); } catch { events = raw.split('\n').filter(Boolean).map((l) => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean); }
  const lines = events.map((e) => (e.payload && e.payload.text) || e.text || '').filter(Boolean);
  console.log('──── Vercel 建置紀錄（最後 80 行）────');
  lines.slice(-80).forEach((l) => console.log(l));
  console.log('──── 結束 ────');
}

// 由 deploy-vercel.ps1 隱藏輸入後放進 AI_KEY_INPUT（AI_PROVIDER_INPUT = gemini | claude）；
// 這裡只轉交給 Vercel，不印出、不存檔。
async function setAIEnv() {
  const key = process.env.AI_KEY_INPUT || '';
  const provider = process.env.AI_PROVIDER_INPUT === 'claude' ? 'claude' : 'gemini';
  if (!key) return false;
  const keyName = provider === 'claude' ? 'ANTHROPIC_API_KEY' : 'GEMINI_API_KEY';
  const backup = process.env.AI_BACKUP_KEY_INPUT || '';
  const target = ['production', 'preview'];
  const res = await fetch(api(`/v10/projects/${PROJECT}/env?upsert=true`), {
    method: 'POST',
    headers: { ...auth(), 'Content-Type': 'application/json' },
    body: JSON.stringify([
      { key: keyName, value: key, type: 'sensitive', target },
      { key: 'AI_PROVIDER', value: provider, type: 'plain', target },
      ...(provider === 'gemini' && backup && backup !== key ? [{ key: 'GEMINI_API_KEY_BACKUP', value: backup, type: 'sensitive', target }] : []),
    ]),
  });
  if (!res.ok) {
    let msg = ''; try { const j = await res.json(); msg = (j.error && (j.error.code + ' ' + j.error.message)) || ''; } catch {}
    console.error(`設定環境變數失敗：HTTP ${res.status} ${msg}（繼續部署，AI 問答會顯示尚未設定金鑰）`);
    return false;
  }
  console.log(`已在 Vercel 設定 ${keyName}（加密）與 AI_PROVIDER=${provider}` + (provider === 'gemini' && backup && backup !== key ? '，以及備用金鑰 GEMINI_API_KEY_BACKUP（加密）' : ''));
  return true;
}

async function main() {
  await setAIEnv();
  const li = process.argv.indexOf('--logs');
  if (li > -1) {
    if (!TOKEN) { console.error('缺少 VERCEL_TOKEN。'); process.exit(1); }
    await printLogs(process.argv[li + 1]);
    return;
  }
  const list = await walk(SITE);
  const files = [];
  let total = 0;
  for (const f of list) {
    const buf = await readFile(f.full);
    files.push({ ...f, buf, size: buf.length, sha: createHash('sha1').update(buf).digest('hex') });
    total += buf.length;
  }
  console.log(`準備上傳 ${files.length} 個檔案，共 ${(total / 1048576).toFixed(1)} MB`);
  if (DRY) { files.forEach((f) => console.log('  ' + f.rel)); return; }
  if (!TOKEN) { console.error('缺少 VERCEL_TOKEN。請先在 vercel.com/account/tokens 建立 token，再設定 $env:VERCEL_TOKEN。'); process.exit(1); }

  let done = 0;
  const queue = files.slice();
  await Promise.all(Array.from({ length: 6 }, async () => {
    while (queue.length) { const f = queue.shift(); await upload(f); done++; if (done % 20 === 0 || done === files.length) console.log(`  已上傳 ${done}/${files.length}`); }
  }));

  const res = await fetch(api('/v13/deployments?skipAutoDetectionConfirmation=1'), {
    method: 'POST',
    headers: { ...auth(), 'Content-Type': 'application/json' },
    body: JSON.stringify({
      name: PROJECT,
      target: 'production',
      files: files.map((f) => ({ file: f.rel, sha: f.sha, size: f.size })),
      projectSettings: { framework: 'nextjs', installCommand: 'npm ci', buildCommand: 'next build', outputDirectory: null, devCommand: null, rootDirectory: null },
    }),
  });
  const dep = await res.json();
  if (!res.ok) { console.error('建立部署失敗：', JSON.stringify(dep)); process.exit(1); }
  console.log(`部署已建立：${dep.id}，建置中…`);

  for (let i = 0; i < 120; i++) {
    await new Promise((r) => setTimeout(r, 5000));
    const s = await (await fetch(api(`/v13/deployments/${dep.id}`), { headers: auth() })).json();
    const state = s.readyState || s.status;
    if (state === 'READY') {
      const urls = [...new Set([...(s.alias || []), s.url].filter(Boolean))];
      console.log('部署完成 ✔');
      urls.forEach((u) => console.log('  https://' + u));
      console.log('檢查 AI 設定：打開上面網址加上 /api/status');
      return;
    }
    if (state === 'ERROR' || state === 'CANCELED') { console.error(`部署失敗（${state}）：${dep.id}`); await printLogs(dep.id); process.exit(1); }
    if (i % 6 === 0) console.log(`  狀態：${state}`);
  }
  console.error('等了 10 分鐘仍未完成，請到 Vercel 網站查看：' + dep.id);
}

main().catch((e) => { console.error(e.message || e); process.exit(1); });
