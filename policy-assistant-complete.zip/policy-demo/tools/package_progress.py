"""Create a portable progress archive without credentials or dependencies."""
from pathlib import Path
import zipfile,json,hashlib,re
root=Path(__file__).resolve().parents[2]
base=root/'policy-demo';out=root/'交接給Gemini';out.mkdir(exist_ok=True)
skip={'.git','node_modules','.next','.vinext','.wrangler','.sites-runtime','.codex','.agents','dist','outputs','work','__pycache__','package-stage'}
files=[]
for p in base.rglob('*'):
    if not p.is_file():continue
    rel=p.relative_to(base)
    if any(s in skip for s in rel.parts) or p.name.startswith('.env') or p.suffix in {'.pem','.key','.tsbuildinfo','.gz','.zip'} or p.name=='.npmrc':continue
    files.append((p,'policy-demo/'+rel.as_posix()))
files += [(p,'原始資料/'+p.name) for p in root.iterdir() if p.is_file() and p.suffix.lower() in {'.pdf','.xlsx'}]
for p,n in files:
    if p.suffix.lower() in {'.txt','.md','.json','.js','.mjs','.ts','.tsx','.css','.yml','.yaml'}:
        if re.search(r'(?:sk-ant-[A-Za-z0-9_-]{20,}|ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{25,})',p.read_text(encoding='utf-8-sig',errors='replace')):raise RuntimeError('Credential-like text detected; archive blocked.')
archive=out/'機器人最新進度備份.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,strict_timestamps=False) as z:
    for p,n in files:z.write(p,n)
    z.writestr('檔案清單.json',json.dumps([{'path':n,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p,n in files],ensure_ascii=False))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print(f'{archive}\n{len(files)} files, {archive.stat().st_size/1048576:.2f} MB, verified')
