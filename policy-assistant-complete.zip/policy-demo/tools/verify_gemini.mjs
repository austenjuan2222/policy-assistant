// Reads an explicitly supplied local key file; never logs credentials or upstream error bodies.
import fs from 'node:fs';
import {buildGeminiRequest,parseGeminiResponse} from '../site/lib/gemini.mjs';
const key=fs.readFileSync(process.argv[2],'utf8').replace(/^\uFEFF/,'').trim();
const data=JSON.parse(fs.readFileSync(new URL('../site/lib/knowledge.json',import.meta.url),'utf8'));
const p=buildGeminiRequest('安心加倍防癌的等待期間多久？','SCB',[],data);
try{
 const r=await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent',{method:'POST',headers:{'Content-Type':'application/json','x-goog-api-key':key},body:JSON.stringify(p.body),signal:AbortSignal.timeout(55000)});
 if(!r.ok){let code,message;try{const e=(await r.json()).error;code=e?.status;message=String(e?.message||'').split(key).join('[REDACTED]').slice(0,1200);}catch{}console.log(JSON.stringify({ok:false,http:r.status,code,message}));process.exitCode=1;}
 else {const body=await r.json();const result=parseGeminiResponse(body,p.sources);console.log(JSON.stringify({ok:true,model:result.model,mode:result.mode,pages:result.sources.map(s=>s.page),answer:result.answer,usage:body.usageMetadata}));}
}catch(e){console.log(JSON.stringify({ok:false,error:e instanceof Error&&/引用|限制|文字|格式/.test(e.message)?e.message:'Connection or request failed'}));process.exitCode=1;}
