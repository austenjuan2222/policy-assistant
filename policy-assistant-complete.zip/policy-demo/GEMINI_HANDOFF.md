## 最新修正（優先於下方歷史紀錄）

已依使用者提供的三項建議完成修正：
1. API 拒絕 null、陣列及損壞 JSON，回傳 400。支援 question/query、history.text/content，相互衝突的查詢欄位拒絕處理。過濾無效 history 元素及 system role，限制訊息長度及歷史筆數。
2. 保留 Claude 原生 citations 格式，不採 XML parser。沒有引用時回傳 claude_unverified，UI 與匯出紀錄都標示「未附來源、尚未核對條款」。偽造／格式損壞引用、截斷或空回覆仍拒絕。沒有實際 Claude API 金鑰，因此只驗證解析邏輯，未完成真實模型測試。
3. 手機 <=980px 新增原生 dialog 來源抽屜，包含完整原文、頁碼切換、PDF 連結與關閉按鈕。支援 Escape、焦點管理、遮罩關閉與減少動畫偏好。

驗證：30 項 Node 測試通過，TypeScript 檢查通過；6 項真實 HTTP 請求覆蓋無效 JSON 與相容格式。390×844 手機版已實測查詢、開啟來源抽屜、內容顯示與關閉。
仍未完成：正式 build、私人部署、簡報與 Claude 真實連線。舊 ZIP 為歷史快照，應使用本修正版文字檔接續。

# 保單客服查詢機器人：Gemini 接續交接

交接日期：2026-10-18。使用者要求先移交目前進度，開發因此暫停。

## 先讀這一段

這是一個**已能本機操作的開發初版**，不是已完成上線的產品。不要宣稱已完成 Claude 真實問答、正式部署或簡報。

使用者要求：以三個第一金人壽商品為例，建立能替代客服回答保單問題的 AI 查詢機器人，最終交付「可操作 demo＋簡報」。回答模型仍指定 **Claude**。Gemini 在本次交接中是開發接手者，使用者尚未要求將產品回答模型改成 Gemini。

使用者選擇私人分享網址，不要公開。尚未決定分享對象，所以維持只有擁有者可存取。使用者沒有 Claude API 金鑰，已同意先完成可設定金鑰的版本。不要要求在聊天貼金鑰，不要用模擬答案冒充 Claude 實際回答。

## 目前完成與未完成

|項目|狀態|
|---|---|
|12 份原始文件盤點與文字擷取|已完成，9 份 PDF 共 80 頁、3 份 Excel|
|商品區隔、文件版本標籤、SHA-256|已完成初版|
|費率結構化|408 筆，含商品、年齡、性別、年期、單位及儲存格來源|
|網頁|本機可用，有客服問答、文件庫、費率試算、連線設定說明|
|文件查詢|實際搜尋正式條款並顯示原文、PDF 頁碼與來源連結|
|Claude API 程式|已寫好，未用真實金鑰驗證|
|自動化測試|21 項通過；TypeScript 型別檢查通過|
|瀏覽器測試|桌面首頁與防癌等待期查詢已檢查；費率操作、手機版等尚未完整測試|
|正式 build|未完成。Sites helper 找不到 npm；尚未執行直接 build 替代路徑|
|私人網址|已註冊 Site，但未推送、未存版本、未部署，網址尚不能當成已上線成果|
|簡報|尚未製作；有一張實際 demo 首頁截圖可使用|
|業務覆核及正式驗收|未完成|

## 檔案位置與可攜結構

交接 ZIP 解壓後：

- `GEMINI_HANDOFF.md`：本文件。
- `給Gemini的提示詞.txt`：可直接貼給 Gemini 的開場提示。
- `原始資料/`：使用者提供的全部 12 份 PDF / Excel，原始檔未修改。
- `policy-demo/site/`：網站程式碼及套件 lockfile，未包含 node_modules。
- `policy-demo/tools/inspect_sources.py`：讀取工作區根目錄中的原始文件，產出解析資料。
- `policy-demo/tools/build_knowledge.py`：產出網站知識 JSON、費率及 PDF 資產。
- `policy-demo/data/`：解析後的原文、文件目錄。
- `policy-demo/build/demo-home.png`：本機實際首頁截圖。
- `測試結果.txt`：此次交接時重跑的測試輸出。

原工作區為 `C:/Users/TESTER/Documents/ChatGPT/保單`，網站在其下 `policy-demo/site`。

在其他電腦重新執行 Python 匯入腳本前，請先把 `原始資料/` 中的文件複製到解壓根目錄（與 policy-demo 同層），或修改腳本 ROOT 的來源設定。**只啟動網站不需要重新跑 Python**，`lib/knowledge.json` 與 PDF 資產已備妥。

## 技術架構

- Sites 提供的 Vinext / React / TypeScript starter。
- `app/page.tsx`：伺服器端只把商品、文件 metadata、問題清單傳至前端。
- `app/demo.tsx`：主要操作介面，對話僅存在頁面記憶體，支援匯出文字紀錄。
- `app/globals.css`：綠色系三欄設計，含響應式規則。
- `lib/knowledge.json`：商品、原文頁面、費率與版本提醒。
- `lib/engine.mjs`：商品識別、關鍵字與雙字元檢索、費率查表、Claude request 與引用驗證。
- `app/api/query/route.ts`：文件模式或 Claude 問答。完整傳入所選商品正式條款頁面，避免跨頁限制遺漏。
- `app/api/rate/route.ts`：數字由程式查表計算，不交給模型猜測。
- `app/api/status/route.ts`：只回傳金鑰是否設定與模型 ID，不回傳金鑰。
- `tests/engine.test.mjs`：21 項測試，包含商品混用、費率、邊界、檢索與引用驗證。
- `public/documents/`：9 份原始 PDF，使用文件 ID 命名。Excel 整本未發布，避免隱藏／內部比較資料外流。

目前檢索是輕量關鍵字與雙字元比對，不是向量資料庫。Claude 呼叫每次讀取所選商品完整條款（13、27 或 28 頁），適合三商品展示但擴大時需調整 token 成本、檢索與快取設計。DM 保留於文件庫，但目前問答檢索與 Claude 問答只使用正式條款。費率另走結構化查表。

## 開發指令

需要 Node >=22.13，建議使用 Node 22，並確保 npm 可用。

```text
cd policy-demo/site
npm ci
node scripts/run-framework.mjs dev
node --test tests/engine.test.mjs
node node_modules/typescript/bin/tsc --noEmit
node scripts/run-framework.mjs build
```

本機網址通常為 http://127.0.0.1:5173/ 。跨電腦不能使用原電腦的 localhost 網址。

原環境 Node 在 `C:/Users/TESTER/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe`，只有 Node、沒有 npm 命令。Sites 安裝 helper 因找不到 npm 而失敗；實際依賴已透過 bundled pnpm 的 `dlx npm run install:ci` 安裝成功。原環境執行 helper build 又遇到相同 npm 缺失，尚未修正。

npm 安裝輸出另提醒 esbuild、workerd 等 install scripts 被阻擋。開發服務目前成功啟動，但正式 build 仍需檢查平台二進位依賴；不要為此任意略過錯誤或宣稱 build 通過。

## Claude 設定

- 伺服器秘密環境變數：`ANTHROPIC_API_KEY`。
- 可選模型變數：`ANTHROPIC_MODEL`，目前預設 `claude-sonnet-5-5`，使用前以帳號可用模型確認。
- 呼叫端點固定為 `https://api.anthropic.com/v1/messages`，header 使用 `anthropic-version: 2023-06-01`。
- 每一 PDF 頁是啟用 citations 的 text document，回傳的 document_index 對回原始頁碼。
- 現有引用驗證檢查引用字串是否存在所指頁面，不能證明結論在語意上正確。未實測模型回答品質。
- 無引用或輸出截斷時回傳提示，沒有默默降級成假 Claude 回答。
- 金鑰缺少時 Claude 模式回傳明確提示，文件模式可正常使用。
- `連線與設定` 頁目前是設定說明與狀態檢查，**不是金鑰儲存表單**。用 Sites 原生環境變數秘密設定完成正式連線。
- 需驗證正式 Cloudflare Workers 部署下 `process.env` 是否能讀到 Sites 的 runtime secrets。

官方參考（2026-10-18 查閱）：
- https://platform.claude.com/docs/en/build-with-claude/citations
- https://platform.claude.com/docs/en/api/overview

## 資料問題與保險內容注意點

1. 商品 ID：RAC＝安新 100 終身保險；RAE2＝享安心終身保險；SCB＝安心加倍防癌定期保險。
2. SCB 的 DM 是 15 年期，但費率表正式資料僅 20 年期、40～65 歲。不能算 15 年期，demo 會拒絕此組合。
3. SCB 費率工作表前段有互動計算器，第 5 列不是正式費率列，匯入已排除。只匯入第 8～59 列。
4. 享安心 Excel 含 GP&Loading、成本分析、隱藏 Compare。只取 GP&Loading 的 A:C 與 E:G 正式費率區域，排除比較與成本資料。
5. 享安心 20 年期 DM 為 2023-07-01，條款為 2023-09-01。適用關係尚待公司確認，不能假定所有文件同版。
6. 安新 100 條款備查 2021-07-01；DM 內頁標記 2022-09-02，與檔名日期不同。以內頁版本作標示。
7. 三份條款為樣本，不含特定保戶批註、附約、生效日期或核保結果。不做個案一定理賠的結論。
8. 來源文字使用 NFKC 正規化，部分標點與相容字會轉換。頁碼保持 PDF 實際頁序，原始 PDF 未修改。

## 已知待修項目

- 手機版 CSS 在 980px 以下隱藏來源側欄，點引用目前不能在手機展開完整原文。應加抽屜或對話框並保留 PDF 連結。
- 桌面文字偏小、偏淡，建議進一步檢查可讀性及 WCAG 對比。
- 查詢為 demo 級關鍵字檢索，來源原文有時從頁首截取，未必第一眼命中問題段落。可改善片段定位與醒目標示。
- 文件模式的後續追問沒有使用歷史文字重新檢索；Claude 模式會傳最近使用者問題，但未傳前次 assistant 回答。
- 輸入 API 沒有完整 rate limit、耐久審計、公司角色權限；私人 Site 權限是當前存取邊界。不能直接當成對外正式客服上線。
- 前端 UI 與 API 錯誤、費率邊界、手機版、PDF 開啟仍需端到端測試。
- 應避免 JSON null、非物件、history 非預期元素造成 API 500，增加輸入結構驗證。
- Claude 回覆缺乏引用時一律拒絕，可能連合理澄清也拒絕，可在不放寬事實引用原則下改善。
- 非特定年齡的保費問句未必進費率路由，可增加穩健的費率意圖判定與追問。

## Site 登記狀態

已建立且保存在 `site/.openai/hosting.json`：

- project_id：`appgprj_6ad468fab3a88191a6282d0ed116eb42`
- slug：`policy-assistant-three-products-1018`
- 預期網址：https://policy-assistant-three-products-1018.fuzzyanole33.chatgpt.site
- 已註冊、未部署，以上不是已上線網址。
- 目前只有擁有者權限。不要為了部署改公開。
- 臨時 Git 憑證不包含在交接包，接手後需透過原帳號 Sites 工具重新取得。不要重新註冊同一 Site。
- 若 Gemini 無法使用 Sites 插件，先完成本機 build、簡報與程式，將部署留給有該 Sites 存取權的工具，或由使用者選定替代私人部署環境。不能保證 Gemini 能取得原服務權限。

## 建議接續順序

1. 讀本文件、測試輸出及來源目錄，確認工作區可啟動。
2. 修正已知手機來源、輸入驗證問題，完成費率和 PDF UI 測試。
3. 完成 production build，驗證 secrets、錯誤回應與伺服器端金鑰隔離。
4. 製作約 12 頁可編輯繁體中文簡報，並附 demo 操作腳本和交付說明。
5. 透過可用且授權的方式部署私人網址。尚未有分享對象，不新增訪客。
6. 如仍無 Claude 金鑰，交付時明確說明真實模型測試待設定後完成，不能報告已完整上線。

## 簡報建議內容

專案目標、客服查詢痛點、三商品與資料盤點、使用者問答流程、完整條款與費率分流、來源追溯、demo 實際畫面、示範問題、資料缺口、已測／未測項目、私人部署與 Claude 啟用、擴充到大量文件的路線。

不要填入虛構節省工時、正確率或真實 Claude 成績。21 項通過只是程式邏輯測試，不是保險專業或模型回答品質驗收。
